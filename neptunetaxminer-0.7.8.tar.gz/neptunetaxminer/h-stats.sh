API_TIMEOUT=10

function stats() {
  stats_raw=$(cat /tmp/npt_miner_stats 2>/dev/null)

  if [[ -z "$stats_raw" || "$stats_raw" == "null" ]]; then
    khs=0
    stats='{"hs":[0],"hs_units":"hs","uptime":0,"ar":[0,0],"temp":[],"power":[],"total_khs":0}'
    return
  fi

  current_time=$(date +%s)
  uptime=0
  gpu_hashrates=$(echo "$stats_raw" | jq '[.devices[]?.hashrate // 0]' 2>/dev/null || echo '[0]')
  total_hs=$(echo "$gpu_hashrates" | jq 'add // 0' 2>/dev/null || echo '0')
  if [[ "$total_hs" == "0" || -z "$total_hs" ]]; then
    total_khs=0
  else
    total_khs=$(awk "BEGIN {printf \"%.6f\", $total_hs / 1000}")
  fi

  gpu_temps='[]'
  gpu_power='[]'
  shares='[0,0]'
  khs=$total_khs
  stats=$(jq -nc \
    --argjson hs "$gpu_hashrates" \
    --arg hs_units "hs" \
    --argjson temp "$gpu_temps" \
    --argjson power "$gpu_power" \
    --argjson uptime "$uptime" \
    --argjson total_khs "$total_khs" \
    --argjson ar "$shares" \
    '{$hs, $hs_units, $temp, $power, $uptime, $total_khs, $ar}')
}

stats
